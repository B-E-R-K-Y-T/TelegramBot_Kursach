--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'ru_RU.UTF-8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai (
    id integer,
    id_message integer,
    dialogs text NOT NULL,
    stickers json
);


ALTER TABLE public.ai OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id integer,
    id_message integer NOT NULL,
    id_users integer,
    user_name text,
    dialogs text
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: usr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usr (
    id integer,
    id_message integer,
    dialogs text NOT NULL
);


ALTER TABLE public.usr OWNER TO postgres;

--
-- Data for Name: ai; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai (id, id_message, dialogs, stickers) FROM stdin;
\.
COPY public.ai (id, id_message, dialogs, stickers) FROM '$$PATH$$/4004.dat';

--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, id_message, id_users, user_name, dialogs) FROM stdin;
\.
COPY public.messages (id, id_message, id_users, user_name, dialogs) FROM '$$PATH$$/4005.dat';

--
-- Data for Name: usr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usr (id, id_message, dialogs) FROM stdin;
\.
COPY public.usr (id, id_message, dialogs) FROM '$$PATH$$/4006.dat';

--
-- Name: ai ai_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai
    ADD CONSTRAINT ai_pkey PRIMARY KEY (dialogs);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id_message);


--
-- Name: usr usr_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usr
    ADD CONSTRAINT usr_pkey PRIMARY KEY (dialogs);


--
-- Name: messages messages_dialogs_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_dialogs_fkey FOREIGN KEY (dialogs) REFERENCES public.ai(dialogs);


--
-- Name: messages messages_dialogs_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_dialogs_fkey1 FOREIGN KEY (dialogs) REFERENCES public.usr(dialogs);


--
-- Name: usr usr_dialogs_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usr
    ADD CONSTRAINT usr_dialogs_fkey FOREIGN KEY (dialogs) REFERENCES public.ai(dialogs);


--
-- PostgreSQL database dump complete
--

